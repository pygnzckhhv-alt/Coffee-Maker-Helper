# ☕ Coffee Companion

A simple web app that helps you make the best possible cup of coffee at home on a semi-manual espresso machine, with either a built-in or separate grinder.

Pick a drink and get the beans, grind, dose, shot size, milk, cup size and method, scaled for 1–4 cups.

## Features

- **Nine drinks:** short black, long black, americano, piccolo latte, macchiato, flat white, cappuccino, latte and mocha
- **Per-drink specs:** bean dose (g), shot yield (ml), extraction time, milk and hot water amounts, cup size, foam style and step-by-step method
- **Grinder toggle:** guidance for built-in or separate grinders
- **Cup scaler:** quantities for 1–4 cups
- **Beans guide:** how to buy, which roast suits which drink, and how to store beans
- **Dial-in & fixes:** a grind-adjustment table for sour, bitter, fast and slow shots
- **Care guide:** cups, milk jug and a machine cleaning schedule
- Light and dark mode, mobile friendly

## Project structure

```
coffee-companion/
├── index.html   # the whole app (HTML, CSS and JavaScript)
├── README.md
└── .gitignore
```

There is no build step, framework or dependencies.

## Run locally

Open `index.html` in a browser, or serve the folder:

```bash
npx serve .
```

## Deploy to Vercel

**Option 1: via GitHub (recommended)**

1. Push this repo to GitHub.
2. Go to [vercel.com/new](https://vercel.com/new) and import the repo.
3. Leave all settings as default (Vercel detects a static site) and click **Deploy**.

Every push to `main` then redeploys automatically, and each branch or pull request gets a preview URL.

**Option 2: via the CLI**

```bash
npm i -g vercel
vercel          # preview deployment
vercel --prod   # production deployment
```

## Customising

All drink data lives in the `DRINKS` object near the top of the script in `index.html`. Edit the doses, milk amounts or steps there, or add a new drink by adding another entry.

## A note on the numbers

The measurements are standard starting points (for example an 18 g dose giving 36–40 ml in 25–30 seconds for a double shot). Every machine, grinder and bean behaves differently, so taste and adjust.

## Licence

Add a licence of your choice (for example MIT) before sharing publicly.
